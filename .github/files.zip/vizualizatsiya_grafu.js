/**
 * D3.js Візуалізація Семантичного Графа Легенди Сі
 * Інтерактивний граф з force simulation
 */

class SemantychnyyGrafViewer {
    constructor(containerId, options = {}) {
        this.container = document.getElementById(containerId);
        
        if (!this.container) {
            throw new Error(`Container з id="${containerId}" не знайдено`);
        }
        
        // Налаштування
        this.options = {
            width: options.width || this.container.clientWidth || 800,
            height: options.height || this.container.clientHeight || 600,
            nodeRadius: {
                0: 24,  // центр
                1: 18,  // глибина 1
                2: 14,  // глибина 2
                3: 12,  // глибина 3
                4: 10,  // глибина 4
                5: 9    // глибина 5
            },
            colors: {
                0: '#ffd700',  // золотий - центр
                1: '#e7c065',  // світло-золотий
                2: '#d4af37',  // темно-золотий
                3: '#c5a552',  // бронза
                4: '#b8975f',  // темна бронза
                5: '#a68a5c'   // глибока бронза
            },
            linkColor: '#e7c065',
            linkOpacity: 0.4,
            linkWidth: 2,
            ...options
        };
        
        this.svg = null;
        this.simulation = null;
        this.nodes = [];
        this.links = [];
        this.potochnyyVuzol = null;
    }
    
    /**
     * Завантажити граф з API
     */
    async zavantatyGraf() {
        try {
            const response = await fetch('/api/kazkar/legenda/graf');
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const data = await response.json();
            
            this.nodes = data.vuzly.map(v => ({
                ...v,
                x: this.options.width / 2,
                y: this.options.height / 2
            }));
            
            // Створити links з об'єктами замість ID
            this.links = [];
            data.vuzly.forEach(vuzol => {
                vuzol.zv_yazani_vuzly.forEach(targetId => {
                    this.links.push({
                        source: vuzol.id,
                        target: targetId
                    });
                });
            });
            
            this.potochnyyVuzol = data.potochnyi_vuzol;
            
            this.renderyty();
            
        } catch (error) {
            console.error('❌ Помилка завантаження графа:', error);
            this.pokazatyPomylku(error.message);
        }
    }
    
    /**
     * Рендеринг графа з D3.js
     */
    renderyty() {
        // Очистити попередній вміст
        this.container.innerHTML = '';
        
        const { width, height } = this.options;
        
        // Створити SVG
        this.svg = d3.select(this.container)
            .append('svg')
            .attr('width', width)
            .attr('height', height)
            .attr('viewBox', [0, 0, width, height]);
        
        // Додати gradient для фону
        const defs = this.svg.append('defs');
        const gradient = defs.append('radialGradient')
            .attr('id', 'background-gradient');
        
        gradient.append('stop')
            .attr('offset', '0%')
            .attr('stop-color', '#1b0f2e');
        
        gradient.append('stop')
            .attr('offset', '100%')
            .attr('stop-color', '#0a0816');
        
        // Фон
        this.svg.append('rect')
            .attr('width', width)
            .attr('height', height)
            .attr('fill', 'url(#background-gradient)');
        
        // Група для графа (для zoom)
        const g = this.svg.append('g');
        
        // Force simulation
        this.simulation = d3.forceSimulation(this.nodes)
            .force('link', d3.forceLink(this.links)
                .id(d => d.id)
                .distance(100)
                .strength(0.5))
            .force('charge', d3.forceManyBody()
                .strength(-400)
                .distanceMax(300))
            .force('center', d3.forceCenter(width / 2, height / 2))
            .force('collision', d3.forceCollide()
                .radius(d => this.getNodeRadius(d) + 10));
        
        // Лінії зв'язків
        const link = g.append('g')
            .attr('class', 'links')
            .selectAll('line')
            .data(this.links)
            .enter()
            .append('line')
            .attr('stroke', this.options.linkColor)
            .attr('stroke-opacity', this.options.linkOpacity)
            .attr('stroke-width', this.options.linkWidth)
            .attr('class', 'link');
        
        // Група для вузлів
        const nodeGroup = g.append('g')
            .attr('class', 'nodes')
            .selectAll('g')
            .data(this.nodes)
            .enter()
            .append('g')
            .attr('class', 'node')
            .call(this.createDragBehavior());
        
        // Зовнішнє світіння для поточного вузла
        nodeGroup.filter(d => d.id === this.potochnyyVuzol)
            .append('circle')
            .attr('r', d => this.getNodeRadius(d) + 8)
            .attr('fill', 'none')
            .attr('stroke', '#ffd700')
            .attr('stroke-width', 3)
            .attr('opacity', 0.6)
            .attr('class', 'current-node-glow')
            .append('animate')
                .attr('attributeName', 'opacity')
                .attr('values', '0.3;0.8;0.3')
                .attr('dur', '2s')
                .attr('repeatCount', 'indefinite');
        
        // Кола вузлів
        nodeGroup.append('circle')
            .attr('r', d => this.getNodeRadius(d))
            .attr('fill', d => this.getNodeColor(d))
            .attr('stroke', d => d.id === this.potochnyyVuzol ? '#ffd700' : '#e7c065')
            .attr('stroke-width', d => d.id === this.potochnyyVuzol ? 3 : 1.5)
            .attr('class', 'node-circle')
            .style('cursor', 'pointer')
            .on('click', (event, d) => this.onNodeClick(event, d))
            .on('mouseenter', (event, d) => this.onNodeHover(event, d))
            .on('mouseleave', (event, d) => this.onNodeLeave(event, d));
        
        // Підписи вузлів
        nodeGroup.append('text')
            .text(d => d.nazva)
            .attr('text-anchor', 'middle')
            .attr('dy', d => this.getNodeRadius(d) + 16)
            .attr('fill', '#e7c065')
            .attr('font-size', d => d.hlybyna === 0 ? '14px' : '11px')
            .attr('font-weight', d => d.hlybyna === 0 ? 'bold' : 'normal')
            .attr('class', 'node-label')
            .style('pointer-events', 'none')
            .style('user-select', 'none');
        
        // Оновлення позицій на кожному тіку
        this.simulation.on('tick', () => {
            link
                .attr('x1', d => d.source.x)
                .attr('y1', d => d.source.y)
                .attr('x2', d => d.target.x)
                .attr('y2', d => d.target.y);
            
            nodeGroup.attr('transform', d => `translate(${d.x},${d.y})`);
        });
        
        // Zoom behavior
        const zoom = d3.zoom()
            .scaleExtent([0.5, 3])
            .on('zoom', (event) => {
                g.attr('transform', event.transform);
            });
        
        this.svg.call(zoom);
        
        // Початковий zoom до центру
        this.svg.call(zoom.transform, d3.zoomIdentity);
    }
    
    /**
     * Отримати радіус вузла за глибиною
     */
    getNodeRadius(node) {
        return this.options.nodeRadius[node.hlybyna] || 10;
    }
    
    /**
     * Отримати колір вузла за глибиною
     */
    getNodeColor(node) {
        return this.options.colors[node.hlybyna] || '#999';
    }
    
    /**
     * Поведінка drag & drop
     */
    createDragBehavior() {
        const simulation = this.simulation;
        
        function dragstarted(event, d) {
            if (!event.active) simulation.alphaTarget(0.3).restart();
            d.fx = d.x;
            d.fy = d.y;
        }
        
        function dragged(event, d) {
            d.fx = event.x;
            d.fy = event.y;
        }
        
        function dragended(event, d) {
            if (!event.active) simulation.alphaTarget(0);
            d.fx = null;
            d.fy = null;
        }
        
        return d3.drag()
            .on('start', dragstarted)
            .on('drag', dragged)
            .on('end', dragended);
    }
    
    /**
     * Клік по вузлу — навігація
     */
    async onNodeClick(event, node) {
        console.log('🔵 Клік по вузлу:', node.nazva);
        
        try {
            const response = await fetch(`/api/kazkar/legenda/navihuvaty/${node.id}`);
            const data = await response.json();
            
            this.potochnyyVuzol = data.potochnyi_vuzol.id;
            
            // Оновити підсвічування
            this.onovytyPidsvichuvannya();
            
            // Викликати callback якщо є
            if (this.options.onNodeSelect) {
                this.options.onNodeSelect(data);
            }
            
            // Показати деталі вузла
            this.pokazatyDetalіVuzla(data.potochnyi_vuzol);
            
        } catch (error) {
            console.error('❌ Помилка навігації:', error);
        }
    }
    
    /**
     * Hover по вузлу
     */
    onNodeHover(event, node) {
        // Збільшити вузол
        d3.select(event.target)
            .transition()
            .duration(200)
            .attr('r', this.getNodeRadius(node) * 1.3);
        
        // Показати tooltip
        this.pokazatyTooltip(event, node);
    }
    
    /**
     * Leave вузла
     */
    onNodeLeave(event, node) {
        // Повернути розмір
        d3.select(event.target)
            .transition()
            .duration(200)
            .attr('r', this.getNodeRadius(node));
        
        // Сховати tooltip
        this.schovatyTooltip();
    }
    
    /**
     * Оновити підсвічування поточного вузла
     */
    onovytyPidsvichuvannya() {
        // Видалити старі glow
        this.svg.selectAll('.current-node-glow').remove();
        
        // Оновити stroke на всіх вузлах
        this.svg.selectAll('.node-circle')
            .attr('stroke', d => d.id === this.potochnyyVuzol ? '#ffd700' : '#e7c065')
            .attr('stroke-width', d => d.id === this.potochnyyVuzol ? 3 : 1.5);
        
        // Додати glow до нового поточного вузла
        this.svg.selectAll('.node')
            .filter(d => d.id === this.potochnyyVuzol)
            .insert('circle', ':first-child')
            .attr('r', d => this.getNodeRadius(d) + 8)
            .attr('fill', 'none')
            .attr('stroke', '#ffd700')
            .attr('stroke-width', 3)
            .attr('opacity', 0.6)
            .attr('class', 'current-node-glow')
            .append('animate')
                .attr('attributeName', 'opacity')
                .attr('values', '0.3;0.8;0.3')
                .attr('dur', '2s')
                .attr('repeatCount', 'indefinite');
    }
    
    /**
     * Показати деталі вузла (sidebar або modal)
     */
    pokazatyDetalіVuzla(vuzol) {
        // Знайти або створити sidebar
        let sidebar = document.getElementById('vuzol-details');
        
        if (!sidebar) {
            sidebar = document.createElement('div');
            sidebar.id = 'vuzol-details';
            sidebar.className = 'vuzol-details-sidebar';
            document.body.appendChild(sidebar);
        }
        
        sidebar.innerHTML = `
            <div class="vuzol-details-content">
                <h3>${vuzol.nazva}</h3>
                <p class="vuzol-sens">${vuzol.sens}</p>
                ${vuzol.arkhetyp ? `<p class="vuzol-arkhetyp">Архетип: ${vuzol.arkhetyp}</p>` : ''}
                <p class="vuzol-hlybyna">Глибина: ${vuzol.hlybyna}</p>
                
                <h4>Зв'язані вузли:</h4>
                <ul class="zvyazani-vuzly">
                    ${vuzol.zv_yazani_vuzly.map(id => 
                        `<li><a href="#" data-vuzol-id="${id}">${this.getVuzolNazva(id)}</a></li>`
                    ).join('')}
                </ul>
            </div>
        `;
        
        sidebar.classList.add('visible');
        
        // Додати обробники кліків на зв'язані вузли
        sidebar.querySelectorAll('[data-vuzol-id]').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const vuzolId = e.target.dataset.vuzolId;
                const node = this.nodes.find(n => n.id === vuzolId);
                if (node) {
                    this.onNodeClick(null, node);
                }
            });
        });
    }
    
    /**
     * Отримати назву вузла за ID
     */
    getVuzolNazva(id) {
        const vuzol = this.nodes.find(n => n.id === id);
        return vuzol ? vuzol.nazva : id;
    }
    
    /**
     * Показати tooltip
     */
    pokazatyTooltip(event, node) {
        let tooltip = document.getElementById('graf-tooltip');
        
        if (!tooltip) {
            tooltip = document.createElement('div');
            tooltip.id = 'graf-tooltip';
            tooltip.className = 'graf-tooltip';
            document.body.appendChild(tooltip);
        }
        
        tooltip.innerHTML = `
            <strong>${node.nazva}</strong><br>
            ${node.sens.substring(0, 60)}...
        `;
        
        tooltip.style.left = `${event.pageX + 10}px`;
        tooltip.style.top = `${event.pageY + 10}px`;
        tooltip.style.display = 'block';
    }
    
    /**
     * Сховати tooltip
     */
    schovatyTooltip() {
        const tooltip = document.getElementById('graf-tooltip');
        if (tooltip) {
            tooltip.style.display = 'none';
        }
    }
    
    /**
     * Показати помилку
     */
    pokazatyPomylku(message) {
        this.container.innerHTML = `
            <div class="error-message">
                <h3>❌ Помилка завантаження</h3>
                <p>${message}</p>
                <button onclick="location.reload()">Перезавантажити</button>
            </div>
        `;
    }
    
    /**
     * Знищити viewer
     */
    destroy() {
        if (this.simulation) {
            this.simulation.stop();
        }
        if (this.svg) {
            this.svg.remove();
        }
        this.container.innerHTML = '';
    }
}

// Експорт для використання
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SemantychnyyGrafViewer;
}
