"""
Розширені семантичні вузли для Легенди Сі
Глибина 4-5: Дія, Потік, Інтенція, Цільність
"""

from dataclasses import dataclass
from typing import List, Optional


@dataclass
class SemantychnyyVuzol:
    """Семантичний вузол у Легенді Сі"""
    id: str
    nazva: str
    sens: str
    zv_yazani_vuzly: List[str]
    arkhetyp: Optional[str]
    hlybyna: int


def otrymaty_rozshyreni_vuzly() -> List[SemantychnyyVuzol]:
    """
    Повертає список розширених семантичних вузлів
    
    Структура:
    - Глибина 4: Дія, Пауза, Потік, Інтенція
    - Глибина 5: Уважність, Живість, Довіра, Цільність, Відпускання, Напруга
    
    Returns:
        List[SemantychnyyVuzol]: 10 нових вузлів
    """
    
    return [
        # ═══════════════════════════════════════════════════════
        # ГЛИБИНА 4 — ДІЯ ТА РУХ
        # ═══════════════════════════════════════════════════════
        
        SemantychnyyVuzol(
            id="diyannya",
            nazva="Дія",
            sens="Усвідомлений рух. Не реакція, а вибір.",
            zv_yazani_vuzly=["moment", "intentsiya", "potik"],
            arkhetyp="podiya",
            hlybyna=4
        ),
        
        SemantychnyyVuzol(
            id="pausa",
            nazva="Пауза",
            sens="Утримання від дії як форма дії. Дозвіл не робити.",
            zv_yazani_vuzly=["diyannya", "spokiy", "pryynyattya"],
            arkhetyp=None,
            hlybyna=4
        ),
        
        SemantychnyyVuzol(
            id="potik",
            nazva="Потік",
            sens="Природний рух без опору. Дія без зусилля.",
            zv_yazani_vuzly=["diyannya", "tsykl", "zhyvist"],
            arkhetyp=None,
            hlybyna=4
        ),
        
        SemantychnyyVuzol(
            id="intentsiya",
            nazva="Інтенція",
            sens="Спрямованість без прив'язаності до результату.",
            zv_yazani_vuzly=["diyannya", "mudrist", "uvazhist"],
            arkhetyp=None,
            hlybyna=4
        ),
        
        # ═══════════════════════════════════════════════════════
        # ГЛИБИНА 5 — ЯКІСТЬ ПРИСУТНОСТІ
        # ═══════════════════════════════════════════════════════
        
        SemantychnyyVuzol(
            id="uvazhist",
            nazva="Уважність",
            sens="Повна присутність у тому, що відбувається зараз.",
            zv_yazani_vuzly=["intentsiya", "prysutnist", "zhyvist"],
            arkhetyp=None,
            hlybyna=5
        ),
        
        SemantychnyyVuzol(
            id="zhyvist",
            nazva="Живість",
            sens="Відчуття енергії життя. Не напруга, а вібрація.",
            zv_yazani_vuzly=["potik", "uvazhist", "tsilnist"],
            arkhetyp=None,
            hlybyna=5
        ),
        
        SemantychnyyVuzol(
            id="dovira",
            nazva="Довіра",
            sens="Відпускання контролю. Довіра процесу без гарантій.",
            zv_yazani_vuzly=["pryynyattya", "pausa", "tsilnist"],
            arkhetyp=None,
            hlybyna=5
        ),
        
        SemantychnyyVuzol(
            id="tsilnist",
            nazva="Цільність",
            sens="Стан, коли всі частини резонують. Відсутність розколу.",
            zv_yazani_vuzly=["balans", "zhyvist", "dovira"],
            arkhetyp="tsentr",
            hlybyna=5
        ),
        
        SemantychnyyVuzol(
            id="vidpuskannya",
            nazva="Відпускання",
            sens="Звільнення від утримування. Не втрата, а легкість.",
            zv_yazani_vuzly=["pausa", "dovira", "mudrist"],
            arkhetyp=None,
            hlybyna=5
        ),
        
        SemantychnyyVuzol(
            id="napruha",
            nazva="Напруга",
            sens="Енергія вибору. Не блок, а ресурс для дії.",
            zv_yazani_vuzly=["diyannya", "pausa", "balans"],
            arkhetyp=None,
            hlybyna=5
        ),
    ]


def validuvaty_zvyazky(vuzly: List[SemantychnyyVuzol]) -> bool:
    """
    Валідує що всі зв'язки вказують на існуючі вузли
    
    Args:
        vuzly: Список вузлів для валідації
        
    Returns:
        bool: True якщо всі зв'язки валідні
    """
    # Створити множину всіх ID
    vsi_id = {v.id for v in vuzly}
    
    # Перевірити кожен зв'язок
    for vuzol in vuzly:
        for zvyazok_id in vuzol.zv_yazani_vuzly:
            if zvyazok_id not in vsi_id:
                print(f"❌ Невалідний зв'язок: {vuzol.id} → {zvyazok_id}")
                return False
    
    print(f"✅ Всі зв'язки валідні ({len(vuzly)} вузлів)")
    return True


# Валідація при імпорті
if __name__ == "__main__":
    vuzly = otrymaty_rozshyreni_vuzly()
    validuvaty_zvyazky(vuzly)
    
    print("\n📊 Статистика розширених вузлів:")
    print(f"  Всього: {len(vuzly)}")
    print(f"  Глибина 4: {len([v for v in vuzly if v.hlybyna == 4])}")
    print(f"  Глибина 5: {len([v for v in vuzly if v.hlybyna == 5])}")
    print(f"  З архетипом: {len([v for v in vuzly if v.arkhetyp])}")
