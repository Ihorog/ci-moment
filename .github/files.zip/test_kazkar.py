"""
Повний набір unit tests для Казкара
Тестує всі аспекти першої формації цілісності
"""

import pytest
from unittest.mock import Mock, patch
import sys
import os

# Додати шлях до модулів
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from zdibnosti.kazkar.forma_opovidi import Kazkar
from zdibnosti.kazkar.prostir_legendy import ProstirLegendy, SemantychnyyVuzol
from zdibnosti.kazkar.dvyhun_arkhetypiv import DvyhunArkhetypiv
from zdibnosti.kazkar.rozshyreni_vuzly import otrymaty_rozshyreni_vuzly, validuvaty_zvyazky
from core.si import si


class TestKazkarAktyvatsiya:
    """Тести активації Казкара"""
    
    def test_aktyvatsiya_bazova(self):
        """Базова активація Казкара"""
        kazkar = Kazkar()
        stan = kazkar.aktyvuvaty()
        
        assert stan is not None
        assert stan["formatsiya"] == "kazkar"
        assert stan["status"] == "aktyvna"
        assert "prostir_legendy" in stan
        assert "dvyhun_arkhetypiv" in stan
    
    def test_aktyvatsiya_z_si(self):
        """Активація Казкара через Сі"""
        si.aktyvuvaty()
        kazkar = Kazkar()
        stan = kazkar.aktyvuvaty()
        
        assert stan["zi_si"] == True
        assert stan["riven_tsilisnosti"] >= 0.8
    
    def test_aktyvatsiya_povtorna(self):
        """Повторна активація не руйнує стан"""
        kazkar = Kazkar()
        stan1 = kazkar.aktyvuvaty()
        stan2 = kazkar.aktyvuvaty()
        
        assert stan1["formatsiya"] == stan2["formatsiya"]
        assert stan2["status"] == "aktyvna"


class TestLegendaSi:
    """Тести Легенди Сі"""
    
    def test_vkhid_u_legendu(self):
        """Вхід у Легенду Сі"""
        kazkar = Kazkar()
        kazkar.aktyvuvaty()
        
        legenda = kazkar.uviyty_v_legendu()
        
        assert legenda is not None
        assert legenda["status"] == "aktyvna"
        assert legenda["potochnyi_vuzol"]["id"] == "prysutnist"
        assert legenda["potochnyi_vuzol"]["hlybyna"] == 0
    
    def test_navihatsiya_bazova(self):
        """Базова навігація по вузлах"""
        kazkar = Kazkar()
        kazkar.aktyvuvaty()
        kazkar.uviyty_v_legendu()
        
        # Навігація до "tysha"
        vuzol = kazkar.prostir_legendy.navihuvaty_do("tysha")
        assert vuzol["potochnyi_vuzol"]["id"] == "tysha"
        assert vuzol["potochnyi_vuzol"]["hlybyna"] == 1
        
        # Навігація до "spokiy"
        vuzol = kazkar.prostir_legendy.navihuvaty_do("spokiy")
        assert vuzol["potochnyi_vuzol"]["id"] == "spokiy"
        assert vuzol["potochnyi_vuzol"]["hlybyna"] == 2
    
    def test_navihatsiya_neisnyuchyi_vuzol(self):
        """Навігація до неіснуючого вузла"""
        kazkar = Kazkar()
        kazkar.aktyvuvaty()
        kazkar.uviyty_v_legendu()
        
        with pytest.raises(ValueError):
            kazkar.prostir_legendy.navihuvaty_do("neisnyuchyi_vuzol")
    
    def test_dostupni_shlyakhy(self):
        """Отримання доступних шляхів з вузла"""
        prostir = ProstirLegendy()
        prostir.aktyvuvaty()
        
        # З центру prysutnist мають бути 3 шляхи
        shlyakhy = prostir.otrymaty_dostupni_shlyakhy()
        assert len(shlyakhy) >= 3
        assert "tysha" in [s["id"] for s in shlyakhy]
        assert "dostatnist" in [s["id"] for s in shlyakhy]
        assert "moment" in [s["id"] for s in shlyakhy]
    
    def test_rezonuyuchi_sensy(self):
        """Отримання резонуючих сенсів"""
        prostir = ProstirLegendy()
        prostir.aktyvuvaty()
        prostir.navihuvaty_do("spokiy")
        
        rezonans = prostir.otrymaty_rezonuyuchi_sensy()
        assert len(rezonans) > 0
        # Має містити зв'язані вузли
        zvyazani_id = [v["id"] for v in rezonans]
        assert "tysha" in zvyazani_id or "balans" in zvyazani_id


class TestSemantychnyyPoshuk:
    """Тести семантичного пошуку"""
    
    def test_poshuk_po_nazvi(self):
        """Пошук по назві вузла"""
        prostir = ProstirLegendy()
        prostir.aktyvuvaty()
        
        rezultat = prostir.poshuk_po_sensu("спокій")
        
        assert len(rezultat["znaideni_vuzly"]) > 0
        znaideni_id = [v["id"] for v in rezultat["znaideni_vuzly"]]
        assert "spokiy" in znaideni_id
    
    def test_poshuk_po_sensu(self):
        """Пошук по змісту сенсу"""
        prostir = ProstirLegendy()
        prostir.aktyvuvaty()
        
        rezultat = prostir.poshuk_po_sensu("зникнення шуму")
        
        assert len(rezultat["znaideni_vuzly"]) > 0
        # Має знайти "tysha"
        znaideni_id = [v["id"] for v in rezultat["znaideni_vuzly"]]
        assert "tysha" in znaideni_id
    
    def test_poshuk_porozhniy_zapyt(self):
        """Пошук з порожнім запитом"""
        prostir = ProstirLegendy()
        prostir.aktyvuvaty()
        
        rezultat = prostir.poshuk_po_sensu("")
        assert len(rezultat["znaideni_vuzly"]) == 0
    
    def test_poshuk_za_arkhetypom(self):
        """Пошук вузлів за архетипом"""
        prostir = ProstirLegendy()
        prostir.aktyvuvaty()
        
        # Знайти всі вузли з архетипом "tsentr"
        vuzly_tsentr = [
            v for v in prostir.vuzly.values()
            if v.arkhetyp == "tsentr"
        ]
        
        assert len(vuzly_tsentr) >= 1
        assert "prysutnist" in [v.id for v in vuzly_tsentr]


class TestArkhetypy:
    """Тести роботи з архетипами"""
    
    def test_zavantazhennya_arkhetypiv(self):
        """Завантаження архетипів з файлу"""
        dvyhun = DvyhunArkhetypiv()
        
        assert len(dvyhun.arkhetypy) == 7
        assert "porig" in dvyhun.arkhetypy
        assert "tvorennya" in dvyhun.arkhetypy
    
    def test_otrymaty_arkhetyp(self):
        """Отримання конкретного архетипу"""
        dvyhun = DvyhunArkhetypiv()
        
        arkhetyp = dvyhun.otrymaty_arkhetyp("porig")
        
        assert arkhetyp is not None
        assert arkhetyp["id"] == "porig"
        assert arkhetyp["nazva"] == "Поріг"
        assert "symvol" in arkhetyp
        assert "sutnist" in arkhetyp
    
    def test_znayty_spilnyi_arkhetyp(self):
        """Знаходження спільного архетипу подій"""
        dvyhun = DvyhunArkhetypiv()
        
        podiyi = [
            {"arkhetyp": "porig"},
            {"arkhetyp": "porig"},
            {"arkhetyp": "tvorennya"}
        ]
        
        spilnyi = dvyhun.znayty_spilnyi(podiyi)
        
        # Має визначити найчастіший або найбільш резонуючий
        assert spilnyi in ["porig", "tvorennya"]
    
    def test_neisnyuchyi_arkhetyp(self):
        """Запит неіснуючого архетипу"""
        dvyhun = DvyhunArkhetypiv()
        
        with pytest.raises(KeyError):
            dvyhun.otrymaty_arkhetyp("neisnyuchyi")


class TestPlestyZvyaznist:
    """Тести плетіння зв'язності між подіями"""
    
    def test_plesty_dvi_podiyi(self):
        """Плетіння зв'язності між двома подіями"""
        kazkar = Kazkar()
        kazkar.aktyvuvaty()
        
        podiyi = [
            {
                "id": "1",
                "tekst": "Сьогодні я зрозумів важливу річ",
                "chas": "2026-02-08T10:00:00Z"
            },
            {
                "id": "2",
                "tekst": "Вчора була подібна ситуація",
                "chas": "2026-02-07T15:00:00Z"
            }
        ]
        
        zvyaznist = kazkar.plesty_zv_yaznist(podiyi)
        
        assert "nytky" in zvyaznist
        assert len(zvyaznist["nytky"]) > 0
        # Має знайти зв'язок між подіями
        assert zvyaznist["nytky"][0]["vid"] in ["1", "2"]
        assert zvyaznist["nytky"][0]["do"] in ["1", "2"]
    
    def test_plesty_bez_podiy(self):
        """Плетіння без подій"""
        kazkar = Kazkar()
        kazkar.aktyvuvaty()
        
        zvyaznist = kazkar.plesty_zv_yaznist([])
        
        assert zvyaznist["nytky"] == []
    
    def test_plesty_odna_podiya(self):
        """Плетіння з однією подією"""
        kazkar = Kazkar()
        kazkar.aktyvuvaty()
        
        podiyi = [{"id": "1", "tekst": "Одна подія"}]
        
        zvyaznist = kazkar.plesty_zv_yaznist(podiyi)
        
        # Одна подія не має зв'язків з іншими
        assert len(zvyaznist["nytky"]) == 0


class TestRozshyreniVuzly:
    """Тести розширених вузлів глибини 4-5"""
    
    def test_kilkist_rozshyrenykh_vuzliv(self):
        """Перевірка кількості розширених вузлів"""
        vuzly = otrymaty_rozshyreni_vuzly()
        
        assert len(vuzly) == 10
    
    def test_hlybyna_vuzliv(self):
        """Перевірка глибини вузлів"""
        vuzly = otrymaty_rozshyreni_vuzly()
        
        hlybyna_4 = [v for v in vuzly if v.hlybyna == 4]
        hlybyna_5 = [v for v in vuzly if v.hlybyna == 5]
        
        assert len(hlybyna_4) == 4
        assert len(hlybyna_5) == 6
    
    def test_klyuchovi_vuzly_isnuyut(self):
        """Перевірка наявності ключових вузлів"""
        vuzly = otrymaty_rozshyreni_vuzly()
        vuzly_id = [v.id for v in vuzly]
        
        assert "diyannya" in vuzly_id
        assert "pausa" in vuzly_id
        assert "potik" in vuzly_id
        assert "tsilnist" in vuzly_id
        assert "dovira" in vuzly_id
    
    def test_validatsiya_zvyazkiv(self):
        """Валідація зв'язків між вузлами"""
        from zdibnosti.kazkar.prostir_legendy import ProstirLegendy
        
        prostir = ProstirLegendy()
        prostir.aktyvuvaty()
        
        # Додати розширені вузли
        rozshyreni = otrymaty_rozshyreni_vuzly()
        for vuzol in rozshyreni:
            prostir.vuzly[vuzol.id] = vuzol
        
        # Всі вузли разом
        vsi_vuzly = list(prostir.vuzly.values())
        
        # Валідувати зв'язки
        assert validuvaty_zvyazky(vsi_vuzly) == True
    
    def test_arkhetypy_rozshyrenykh(self):
        """Перевірка архетипів у розширених вузлах"""
        vuzly = otrymaty_rozshyreni_vuzly()
        
        z_arkhetypom = [v for v in vuzly if v.arkhetyp is not None]
        
        assert len(z_arkhetypom) >= 1
        # "diyannya" має архетип "podiya"
        diyannya = next(v for v in vuzly if v.id == "diyannya")
        assert diyannya.arkhetyp == "podiya"


class TestIntehratsiya:
    """Інтеграційні тести всієї системи"""
    
    def test_povnyi_tsykl_roboty(self):
        """Повний цикл роботи з Казкаром"""
        # 1. Активувати Сі
        si.aktyvuvaty()
        
        # 2. Створити і активувати Казкар
        kazkar = Kazkar()
        stan = kazkar.aktyvuvaty()
        assert stan["status"] == "aktyvna"
        
        # 3. Увійти у Легенду
        legenda = kazkar.uviyty_v_legendu()
        assert legenda["potochnyi_vuzol"]["id"] == "prysutnist"
        
        # 4. Навігація
        kazkar.prostir_legendy.navihuvaty_do("tysha")
        kazkar.prostir_legendy.navihuvaty_do("spokiy")
        
        # 5. Пошук
        rezultat = kazkar.prostir_legendy.poshuk_po_sensu("мудрість")
        assert len(rezultat["znaideni_vuzly"]) > 0
        
        # 6. Плетіння зв'язності
        podiyi = [
            {"id": "1", "tekst": "Перша подія"},
            {"id": "2", "tekst": "Друга подія"}
        ]
        zvyaznist = kazkar.plesty_zv_yaznist(podiyi)
        assert "nytky" in zvyaznist
    
    def test_syhnalizatsiya_trishchyny(self):
        """Тест сигналізації про тріщини в цілісності"""
        kazkar = Kazkar()
        kazkar.aktyvuvaty()
        
        # Симулювати невідповідність
        trishchyna = kazkar.syhnalizuvaty_trishchynu({
            "formatsiya": "kazkar",
            "prychyna": "Конфлікт архетипів"
        })
        
        assert trishchyna is not None
        assert trishchyna["formatsiya"] == "kazkar"
        assert "prychyna" in trishchyna


class TestProduktyvnist:
    """Тести продуктивності"""
    
    def test_shvydkist_poshuku(self):
        """Пошук має бути швидким"""
        import time
        
        prostir = ProstirLegendy()
        prostir.aktyvuvaty()
        
        start = time.time()
        prostir.poshuk_po_sensu("спокій")
        elapsed = time.time() - start
        
        # Пошук має бути швидшим за 100ms
        assert elapsed < 0.1
    
    def test_shvydkist_navihatsii(self):
        """Навігація має бути миттєвою"""
        import time
        
        prostir = ProstirLegendy()
        prostir.aktyvuvaty()
        
        start = time.time()
        for _ in range(100):
            prostir.navihuvaty_do("tysha")
            prostir.navihuvaty_do("spokiy")
            prostir.navihuvaty_do("prysutnist")
        elapsed = time.time() - start
        
        # 100 навігацій має виконуватись за <100ms
        assert elapsed < 0.1


# ═══════════════════════════════════════════════════════
# PYTEST CONFIGURATION
# ═══════════════════════════════════════════════════════

def pytest_configure(config):
    """Конфігурація pytest"""
    config.addinivalue_line(
        "markers", "slow: позначає повільні тести"
    )
    config.addinivalue_line(
        "markers", "integration: інтеграційні тести"
    )


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--cov=zdibnosti/kazkar"])
